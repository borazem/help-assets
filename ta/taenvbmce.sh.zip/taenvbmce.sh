#! /bin bash

echo "Please enter the IBM entitlement key or leave empty if you hve the key set already:"
read ibm_ent_reg_key

if [ -z "$ibm_ent_reg_key" ]
then
      if [ -z "$ENTITLED_REGISTRY_KEY" ]
      then
           echo "enter the ibm entitled registry key"
      else
           echo "the ibm entitlement registry variable set earlier will be used"
      fi	
else
      export ENTITLED_REGISTRY_KEY=$ibm_ent_reg_key
      echo "the variable for the ibm entitled registry key has been set"
fi

export CASE_NAME=ibm-transadv
export CASE_VERSION=2.5.0
export CASE_ARCHIVE=$CASE_NAME-$CASE_VERSION.tgz
export CASE_INVENTORY_SETUP=v2TransAdvOperator
export CASE_INVENTORY_SETUP_OPERATOR=v2TransAdvOperator
export CASE_INVENTORY_SETUP_INSTANCE=v2TransAdv
export CASE_INVENTORY_SETUP_PRODUCT=v2InstallProduct
export OFFLINEDIR=/ocpportdev/ta-offline
export OFFLINEDIR_ARCHIVE=offline.tgz
export CASE_REPO_PATH=https://github.com/IBM/cloud-pak/raw/master/repo/case
export CASE_LOCAL_PATH=$OFFLINEDIR/$CASE_ARCHIVE

export LOCAL_DOCKER_REGISTRY_HOST=belrapss001.eurafric-information.com
export LOCAL_DOCKER_REGISTRY_PORT=8447
export LOCAL_DOCKER_REGISTRY=$LOCAL_DOCKER_REGISTRY_HOST:$LOCAL_DOCKER_REGISTRY_PORT
export LOCAL_DOCKER_REGISTRY_USER=admin
export LOCAL_DOCKER_REGISTRY_PASSWORD=ICPassw0rd#

export NAMESPACE=ta
export TA_PROJECT=$NAMESPACE

export ENTITLED_REGISTRY=cp.icr.io
export ENTITLED_REGISTRY_USER=cp

export TMPDIR=/ocpportdev/tmp/
echo "All Variables are set"